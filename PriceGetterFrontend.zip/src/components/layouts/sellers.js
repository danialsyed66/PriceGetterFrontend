const sellers = [
  {
    text: 'Daraz',
    val: '6222415a65458731887a8ff4',
  },
  {
    text: 'Yayvo',
    val: '622241a965458731887a8ff6',
  },
  {
    text: 'PriceGetter',
    val: 'PriceGetter',
  },
];

export default sellers;
